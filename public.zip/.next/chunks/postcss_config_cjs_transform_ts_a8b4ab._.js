(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["chunks/postcss_config_cjs_transform_ts_a8b4ab._.js", {

"[project]/postcss.config.cjs/transform.ts { CONFIG => \"[project]/postcss.config.cjs [postcss] (ecmascript)\" } [postcss] (ecmascript, async loader)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__((__turbopack_import__) => {
    return Promise.all([
  "chunks/node_modules_dd11ba._.js",
  "chunks/postcss_config_cjs_47f451._.js",
  "chunks/postcss_config_cjs_transform_ts_8d45dc._.js"
].map((chunk) => __turbopack_load__(chunk))).then(() => {
        return __turbopack_import__("[project]/postcss.config.cjs/transform.ts { CONFIG => \"[project]/postcss.config.cjs [postcss] (ecmascript)\" } [postcss] (ecmascript)");
    });
});

})()),
}]);