(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "chunks/[output]__next_transform_49e52f.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "chunks/[output]__next_transform_49e52f.js",
  "chunks": [
    "chunks/[turbopack-node]__d3070d._.js",
    "chunks/postcss_config_cjs_transform_ts_a8b4ab._.js"
  ],
  "source": "entry"
});
