(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_f60fdc._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_f60fdc._.js",
  "chunks": [
    "static/chunks/_8a6a19._.css",
    "static/chunks/node_modules_next_e69441._.js",
    "static/chunks/node_modules_framer-motion_dist_es_92139a._.js",
    "static/chunks/node_modules_@trpc_server_dist_adccfa._.js",
    "static/chunks/node_modules_@trpc_client_dist_787755._.js",
    "static/chunks/node_modules_@tanstack_query-core_build_modern_1fb7ca._.js",
    "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854ac._.js",
    "static/chunks/node_modules_@clerk_shared_dist_3f22b8._.js",
    "static/chunks/node_modules_swr_dist_b28dac._.js",
    "static/chunks/node_modules_@clerk_clerk-react_dist_467d4d._.js",
    "static/chunks/node_modules_eb2f48._.js",
    "static/chunks/src_97e9a2._.js"
  ],
  "source": "dynamic"
});
