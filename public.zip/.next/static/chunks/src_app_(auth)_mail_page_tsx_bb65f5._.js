(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(auth)_mail_page_tsx_d6cbc7._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(auth)_mail_page_tsx_d6cbc7._.js",
  "chunks": [
    "static/chunks/src_989cd2._.js",
    "static/chunks/node_modules_@radix-ui_react-icons_dist_react-icons_esm_ecd85e.js",
    "static/chunks/node_modules_prosemirror-model_dist_index_06373f.js",
    "static/chunks/node_modules_prosemirror-view_dist_index_212d9a.js",
    "static/chunks/node_modules_@tiptap_core_dist_index_bbf028.js",
    "static/chunks/node_modules_@popperjs_core_lib_bbe9b3._.js",
    "static/chunks/node_modules_core-js-pure_651303._.js",
    "static/chunks/node_modules_react-avatar_es_fe106b._.js",
    "static/chunks/node_modules_react-select_dist_aeaafd._.js",
    "static/chunks/node_modules_date-fns_ffc6d7._.js",
    "static/chunks/node_modules_react-day-picker_dist_index_esm_9fc304.js",
    "static/chunks/node_modules_zod_lib_index_mjs_ee760a._.js",
    "static/chunks/node_modules_@radix-ui_f1e0fc._.js",
    "static/chunks/node_modules_@tiptap_e0b8c8._.js",
    "static/chunks/node_modules_@emotion_d774b5._.js",
    "static/chunks/node_modules_@floating-ui_ef84a9._.js",
    "static/chunks/node_modules_@ai-sdk_aa0990._.js",
    "static/chunks/node_modules_be2433._.js"
  ],
  "source": "dynamic"
});
