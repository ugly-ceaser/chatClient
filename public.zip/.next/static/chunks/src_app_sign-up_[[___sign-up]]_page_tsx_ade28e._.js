(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_sign-up_[[___sign-up]]_page_tsx_ade28e._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_sign-up_[[___sign-up]]_page_tsx_ade28e._.js",
  "chunks": [
    "static/chunks/_96e8f6._.js"
  ],
  "source": "dynamic"
});
