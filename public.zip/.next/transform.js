Error.stackTraceLimit = 100;
global.self = global;
require("./chunks/[turbopack-node]__d3070d._.js");
require("./chunks/postcss_config_cjs_transform_ts_a8b4ab._.js");
require("./chunks/[output]__next_transform_49e52f.js");
require("./chunks/[output]__next_transform_d7cb3a.js");
