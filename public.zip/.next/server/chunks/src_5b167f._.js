module.exports = {

"[project]/src/lib/nylas.ts [app-route] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "getNylas": ()=>getNylas,
    "initializeAuthentication": ()=>initializeAuthentication
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nylas$2f$lib$2f$esm$2f$nylas$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/nylas/lib/esm/nylas.js [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nylas$2f$lib$2f$esm$2f$nylas$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/node_modules/nylas/lib/esm/nylas.js [app-route] (ecmascript) <locals>");
"__TURBOPACK__ecmascript__hoisting__location__";
"use server";
;
const config = {
    clientId: process.env.NYLAS_CLIENT_ID,
    callbackUri: `http://localhost:3000/api/auth/callback/nylas`,
    apiKey: process.env.NYLAS_API_KEY,
    apiUri: process.env.NYLAS_API_URI ?? "https://api.us.nylas.com"
};
const nylas = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nylas$2f$lib$2f$esm$2f$nylas$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"]({
    apiKey: config.apiKey,
    apiUri: config.apiUri
});
const getNylas = async ()=>{
    return nylas;
};
const initializeAuthentication = async ()=>{
    const authUrl = nylas.auth.urlForOAuth2({
        redirectUri: config.callbackUri,
        clientId: config.clientId,
        provider: 'google'
    });
    return authUrl;
};

})()),
"[project]/src/env.js [app-route] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "env": ()=>env
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$t3$2d$oss$2f$env$2d$nextjs$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@t3-oss/env-nextjs/dist/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/zod/lib/index.mjs [app-route] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
const env = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$t3$2d$oss$2f$env$2d$nextjs$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createEnv"])({
    /**
   * Specify your server-side environment variables schema here. This way you can ensure the app
   * isn't built with invalid env vars.
   */ server: {
        DATABASE_URL: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().url(),
        NODE_ENV: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].enum([
            "development",
            "test",
            "production"
        ]).default("development")
    },
    /**
   * Specify your client-side environment variables schema here. This way you can ensure the app
   * isn't built with invalid env vars. To expose them to the client, prefix them with
   * `NEXT_PUBLIC_`.
   */ client: {
    },
    /**
   * You can't destruct `process.env` as a regular object in the Next.js edge runtimes (e.g.
   * middlewares) or client-side so we need to destruct manually.
   */ runtimeEnv: {
        DATABASE_URL: process.env.DATABASE_URL,
        NODE_ENV: ("TURBOPACK compile-time value", "development")
    },
    /**
   * Run `build` or `dev` with `SKIP_ENV_VALIDATION` to skip env validation. This is especially
   * useful for Docker builds.
   */ skipValidation: !!process.env.SKIP_ENV_VALIDATION,
    /**
   * Makes it so that empty strings are treated as undefined. `SOME_VAR: z.string()` and
   * `SOME_VAR=''` will throw an error.
   */ emptyStringAsUndefined: true
});

})()),
"[project]/src/server/db.ts [app-route] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "db": ()=>db
});
var __TURBOPACK__commonjs__external__$40$prisma$2f$client__ = __turbopack_external_require__("@prisma/client", true);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$env$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/env.js [app-route] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
const createPrismaClient = ()=>new __TURBOPACK__commonjs__external__$40$prisma$2f$client__["PrismaClient"]({
        log: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$env$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["env"].NODE_ENV === "development" ? [
            "error",
            "warn"
        ] : [
            "error"
        ]
    });
const globalForPrisma = globalThis;
const db = globalForPrisma.prisma ?? createPrismaClient();
if (__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$env$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["env"].NODE_ENV !== "production") globalForPrisma.prisma = db;

})()),
"[project]/src/app/api/auth/callback/nylas/route.ts [app-route] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "GET": ()=>GET
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$nylas$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/nylas.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$server$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/server/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$clerk$2f$nextjs$2f$dist$2f$esm$2f$app$2d$router$2f$server$2f$auth$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@clerk/nextjs/dist/esm/app-router/server/auth.js [app-route] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
async function GET(request) {
    const { userId } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$clerk$2f$nextjs$2f$dist$2f$esm$2f$app$2d$router$2f$server$2f$auth$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["auth"])();
    const nylas = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$nylas$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getNylas"])();
    if (!userId) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "No user ID found"
        }, {
            status: 400
        });
    }
    console.log("Received callback from Nylas");
    const url = new URL(request.url);
    const code = url.searchParams.get("code");
    if (!code) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "No authorization code returned from Nylas"
        }, {
            status: 400
        });
    }
    const codeExchangePayload = {
        clientSecret: process.env.NYLAS_API_KEY,
        clientId: process.env.NYLAS_CLIENT_ID,
        redirectUri: `${("TURBOPACK compile-time value", "http://localhost:3000")}/api/auth/callback/nylas`,
        code
    };
    try {
        const response = await nylas.auth.exchangeCodeForToken(codeExchangePayload);
        const { grantId, email, idToken, provider } = response;
        // CHECK FOR ACCOUNT
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$server$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["db"].$transaction(async (prisma)=>{
            let account = await prisma.account.findFirst({
                where: {
                    id: grantId,
                    userId: idToken
                }
            });
            // CREATE ACCOUNT
            if (!account) {
                account = await prisma.account.create({
                    data: {
                        id: grantId,
                        userId,
                        token: idToken,
                        provider: "Nylas",
                        emailAddress: email,
                        name: provider
                    }
                });
            } else {
                // UPDATE TOKEN
                await prisma.account.update({
                    where: {
                        id: grantId
                    },
                    data: {
                        token: idToken
                    }
                });
            }
            const emails = await nylas.messages.list({
                identifier: grantId,
                queryParams: {
                    limit: 5
                }
            });
            const hasThreads = await prisma.thread.findFirst({
                where: {
                    accountId: grantId
                }
            });
            if (!hasThreads) {
                for (const email of emails.data){
                    const thread = await prisma.thread.create({
                        data: {
                            accountId: grantId,
                            subject: email.subject,
                            lastMessageDate: new Date(email.date * 1000)
                        }
                    });
                    let emailExists = await prisma.emailAddress.findFirst({
                        where: {
                            accountId: grantId,
                            address: email?.from?.[0]?.email
                        }
                    });
                    // CHECK IF EMAIL EXISTS
                    if (!emailExists) {
                        emailExists = await prisma.emailAddress.create({
                            data: {
                                accountId: grantId,
                                address: email?.from?.[0]?.email,
                                name: email.from?.[0]?.name
                            }
                        });
                    } else {
                        emailExists = await prisma.emailAddress.update({
                            where: {
                                id: emailExists?.id
                            },
                            data: {
                                accountId: grantId,
                                address: email?.from?.[0]?.email,
                                name: email.from?.[0]?.name
                            }
                        });
                    }
                    await prisma.email.create({
                        data: {
                            threadId: thread.id,
                            sentAt: new Date(email.date * 1000),
                            createdTime: new Date(email.date * 1000),
                            receivedAt: new Date(email.date * 1000),
                            body: email.body,
                            bodySnippet: email.snippet,
                            fromId: emailExists.id,
                            hasAttachments: !!email?.attachments?.length,
                            subject: email.subject,
                            internetMessageId: email.id,
                            lastModifiedTime: new Date(email.date * 1000)
                        }
                    });
                }
            }
        });
        // UPSERT MESSAGES
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].redirect(new URL("/mail", request.nextUrl.origin));
    } catch (error) {
        console.log({
            error
        });
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "Failed to exchange authorization code for token"
        }, {
            status: 500
        });
    }
}

})()),

};

//# sourceMappingURL=src_5b167f._.js.map