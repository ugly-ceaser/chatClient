(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "chunks/ssr/edge-wrapper_ab6e28.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "chunks/ssr/edge-wrapper_ab6e28.js",
  "chunks": [
    "chunks/ssr/_b38b86._.js",
    "chunks/ssr/src_middleware_ts_9f486c._.js"
  ],
  "source": "entry"
});
