const CHUNK_PUBLIC_PATH = "server/app/sign-up/[[...sign-up]]/page.js";
const runtime = require("../../../chunks/ssr/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/ssr/node_modules_next_5c7977._.js");
runtime.loadChunk("server/chunks/ssr/_a17a1b._.js");
runtime.loadChunk("server/chunks/ssr/node_modules_@clerk_backend_dist_ba645c._.js");
runtime.loadChunk("server/chunks/ssr/node_modules_372f20._.js");
runtime.loadChunk("server/chunks/ssr/src_bc3ce3._.js");
runtime.getOrInstantiateRuntimeModule("[project]/.next-internal/server/app/sign-up/[[...sign-up]]/page/actions.js { ACTIONS_MODULE0 => \"[project]/node_modules/@clerk/nextjs/dist/esm/app-router/server-actions.js [app-rsc] (ecmascript, action, ecmascript)\" } [app-rsc] (ecmascript)", CHUNK_PUBLIC_PATH);
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/node_modules/next/dist/esm/build/templates/app-page.js?page=/sign-up/[[...sign-up]]/page { COMPONENT_0 => \"[project]/src/app/layout.tsx [app-rsc] (ecmascript, Next.js server component)\", COMPONENT_1 => \"[project]/node_modules/next/dist/client/components/not-found-error.js [app-rsc] (ecmascript, Next.js server component)\", COMPONENT_2 => \"[project]/src/app/sign-up/[[...sign-up]]/page.tsx [app-rsc] (ecmascript, Next.js server component)\" } [app-rsc] (ecmascript) <facade>", CHUNK_PUBLIC_PATH).exports;
